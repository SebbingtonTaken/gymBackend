﻿using DataAccess.CRUD;
using DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp
{
    public class TrainingLogManager
    {
             public void Create(TrainingLog exer)
        {
            TrainingLogCrudFactory factory = new TrainingLogCrudFactory();

            factory.Create(exer);
        }

        public void Update(TrainingLog exer)
        {
            TrainingLogCrudFactory factory = new TrainingLogCrudFactory();

            factory.Update(exer, exer.Id);
        }

        public List<TrainingLog> RetrieveAll()
        {

            var factory = new TrainingLogCrudFactory();

            return factory.RetrieveAll<TrainingLog>();
        }

        public TrainingLog RetrieveById(int id)
        {
            var factory = new TrainingLogCrudFactory();

            return factory.RetrieveById<TrainingLog>(id);
        }
    }
}
