﻿using DataAccess.CRUD;
using DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp
{
    public class RoutineDayManager
    {
        public void Create(RoutineDay routineDay)
        {
            RoutineDayCrudFactory factory = new RoutineDayCrudFactory();

            factory.Create(routineDay);
        }

        public void Update(RoutineDay routineDay)
        {
            RoutineDayCrudFactory factory = new RoutineDayCrudFactory();


            factory.Update(routineDay, routineDay.Id);
        }

        public List<RoutineDay> RetrieveAll()
        {

            var factory = new RoutineDayCrudFactory();

            return factory.RetrieveAll<RoutineDay>();

        }

        public RoutineDay RetrieveById(int id)
        {

            var factory = new RoutineDayCrudFactory();

            return factory.RetrieveById<RoutineDay>(id);


        }
    }
}
