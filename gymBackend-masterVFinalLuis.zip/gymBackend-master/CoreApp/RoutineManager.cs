﻿using DataAccess.CRUD;
using DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreApp
{
    public class RoutineManager 
    {
        public void Create(Routines routines)
        {
            RoutineCrudFactory factory = new RoutineCrudFactory();

            factory.Create(routines);
        }

        public void Update(Routines routines)
        {
            RoutineCrudFactory factory = new RoutineCrudFactory();


            factory.Update(routines, routines.Id);
        }

        public List<Routines> RetrieveAll()
        {

            var factory = new RoutineCrudFactory();

            return factory.RetrieveAll<Routines>();

        }

        public Routines RetrieveById(int id)
        {

            var factory = new RoutineCrudFactory();

            return factory.RetrieveById<Routines>(id);


        }
        public List<RoutineDay> RetrieveRoutineDaysByRoutineId(int routineId)
        {
            var factory = new RoutineCrudFactory();
            return factory.RetrieveRoutineDaysByRoutineId(routineId); // Llamada corregida
        }

        public List<Routines> RetrieveRoutinesByUserId(int userId)
        {
            var factory = new RoutineCrudFactory();
            return factory.RetrieveRoutinesByUserId(userId);
        }
    }
}
