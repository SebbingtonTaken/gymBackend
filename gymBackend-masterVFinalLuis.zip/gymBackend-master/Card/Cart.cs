﻿namespace Card
{
    public class Cart
    {

    }
}
