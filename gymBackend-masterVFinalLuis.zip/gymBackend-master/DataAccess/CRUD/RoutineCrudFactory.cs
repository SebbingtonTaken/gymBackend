﻿using DataAccess.DAOs;
using DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.CRUD
{
    public class RoutineCrudFactory : CrudFactory
    {
        private readonly RoutineDayCrudFactory routineDayCrudFactory;
        public RoutineCrudFactory()
            {
                sqlDao = SqlDao.GetInstance();
            routineDayCrudFactory = new RoutineDayCrudFactory();
        }

            public override void Create(BaseDTO baseDTO)
            {
                var routine = baseDTO as Routines;
                var sqlOperation = new SqlOperation
                {
                    ProcedureName = "INS_ROUTINE_PR"
                };
                sqlOperation.AddStringParameter("routine_type", routine.RoutineType);
                sqlOperation.AddIntParameter("user_id", routine.UserId);
                sqlOperation.AddIntParameter("employee_id", routine.EmployeeId);
                sqlOperation.AddDateTimeParameter("creation_date", routine.CreationDate);

                sqlDao.ExecuteProcedure(sqlOperation);
            }

            public override void DeleteByID(int id)
            {
               
            }

            public override List<T> RetrieveAll<T>()
            {
                var routineList = new List<T>();
                var sqlOperation = new SqlOperation
                {
                    ProcedureName = "RET_ALL_ROUTINES_PR"
                };
                var listResult = sqlDao.ExecuteQueryProcedure(sqlOperation);

                if (listResult.Count > 0)
                {
                    foreach (var row in listResult)
                    {
                        var routine = BuildRoutine(row);
                        routineList.Add((T)Convert.ChangeType(routine, typeof(T)));
                    }
                }
                return routineList;
            }

        public T RetrieveById<T>(int id)
        {
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "RET_ROUTINE_BY_ID_PR"
            };
            sqlOperation.AddIntParameter("routine_id", id);

            var listResults = sqlDao.ExecuteQueryProcedure(sqlOperation);

            if (listResults.Count > 0)
            {
                var row = listResults[0];
                var routine = BuildRoutine(row);

                // Solo si T es de tipo Routines, ejecuta este bloque
                if (routine is Routines)
                {
                    routine.RoutineDay = RetrieveRoutineDaysByRoutineId(routine.Id);
                    return (T)(object)routine;
                }

                return (T)Convert.ChangeType(routine, typeof(T));
            }
            return default(T);
        }

        public List<RoutineDay> RetrieveRoutineDaysByRoutineId(int routineId)
        {
            var routineDayList = new List<RoutineDay>();
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "RET_ROUTINEDAY_BY_ROUTINEID_PR"
            };
            sqlOperation.AddIntParameter("routine_id", routineId);

            var listResult = sqlDao.ExecuteQueryProcedure(sqlOperation);

            if (listResult.Count > 0)
            {
                foreach (var row in listResult)
                {
                    var routineDay = routineDayCrudFactory.BuildRoutineDay(row);
                    routineDayList.Add(routineDay);
                }
            }
            return routineDayList;
        }

        public List<Routines> RetrieveRoutinesByUserId(int userId)
        {
            var routineList = new List<Routines>();
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "RET_ROUTINES_BY_USER_ID_PR"
            };
            sqlOperation.AddIntParameter("user_id", userId);

            var listResult = sqlDao.ExecuteQueryProcedure(sqlOperation);

            if (listResult.Count > 0)
            {
                foreach (var row in listResult)
                {
                    var routine = BuildRoutine(row);
                    routine.RoutineDay = RetrieveRoutineDaysByRoutineId(routine.Id); 
                    routineList.Add(routine);
                }
            }
            return routineList;
        }
        public override void Update(BaseDTO baseDTO, int? id)
            {
                var routine = baseDTO as Routines;
                var sqlOperation = new SqlOperation
                {
                    ProcedureName = "UP_ROUTINES_PR"
                };
                sqlOperation.AddIntParameter("routine_id", id.Value);
                sqlOperation.AddStringParameter("routine_type", routine.RoutineType);
                sqlOperation.AddIntParameter("user_id", routine.UserId);
                sqlOperation.AddIntParameter("employee_id", routine.EmployeeId);
            sqlOperation.AddDateTimeParameter("creation_date", routine.CreationDate);

            sqlDao.ExecuteProcedure(sqlOperation);
            }

            private Routines BuildRoutine(Dictionary<string, object> row)
            {
            var routine = new Routines
            {
                RoutineType = (string)row["routine_type"],
                RoutineDay = new List<RoutineDay>(),
                UserId = (int)row["user_id"],
                EmployeeId = (int)row["employee_id"],
                CreationDate = (DateTime)row["creation_date"],
            };
            
            return routine;
            }
        }
    }

