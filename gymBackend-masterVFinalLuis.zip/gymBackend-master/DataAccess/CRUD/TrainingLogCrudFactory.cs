﻿using DataAccess.DAOs;
using DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.CRUD
{
    public class TrainingLogCrudFactory : CrudFactory
    {
        public TrainingLogCrudFactory()
        {
            sqlDao = SqlDao.GetInstance();
        }

        public override void Create(BaseDTO baseDTO)
        {
            var trainingLog = baseDTO as TrainingLog;
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "INS_USER_PROGRESS_PR"
            };
            sqlOperation.AddIntParameter("user_id", trainingLog.UserId);
            sqlOperation.AddIntParameter("routine_day_id", trainingLog.RoutineDayId);
            sqlOperation.AddIntParameter("exercise_id", trainingLog.ExerciseId);
            sqlOperation.AddIntParameter("sets_completed", trainingLog.Sets);
            sqlOperation.AddIntParameter("repetition_completed", trainingLog.Reps);
            sqlOperation.AddDoubleParameter("weight_used", trainingLog.Weight);
            sqlOperation.AddTimeParameter("time_taken", trainingLog.Time);
            sqlOperation.AddDateTimeParameter("creation_date", trainingLog.CreationDate);

            sqlDao.ExecuteProcedure(sqlOperation);
        }

        public override void DeleteByID(int id)
        {
            throw new NotImplementedException();
        }

        public override List<T> RetrieveAll<T>()
        {
            var TrainingList = new List<T>();
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "RET_ALL_USER_PROGRESS_PR"
            };
            var listResult = sqlDao.ExecuteQueryProcedure(sqlOperation);

            if (listResult.Count > 0)
            {
                foreach (var row in listResult)
                {
                    var trainingLog = BuildtrainingLog(row);
                    TrainingList.Add((T)Convert.ChangeType(trainingLog, typeof(T)));
                }
            }
            return TrainingList;
        }
        public T RetrieveById<T>(int id)
        {
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "RET_USER_PROGRESS_BY_USER_ID_PR"
            };
            sqlOperation.AddIntParameter("@user_id", id);

            var listResults = sqlDao.ExecuteQueryProcedure(sqlOperation);

            if (listResults.Count > 0)
            {
                var row = listResults[0];
                var trainingLog = (T)Convert.ChangeType(BuildtrainingLog(row), typeof(T));
                return trainingLog;
            }
            return default(T);
        }

        public override void Update(BaseDTO baseDTO, int? id)
        {
            var trainingLog = baseDTO as TrainingLog;
            var sqlOperation = new SqlOperation();

            sqlOperation.ProcedureName = "UP_USER_PROGRESS_PR";
            sqlOperation.AddIntParameter("progress_id", trainingLog.Id);
            sqlOperation.AddIntParameter("user_id", trainingLog.UserId);
            sqlOperation.AddIntParameter("routine_day_id", trainingLog.RoutineDayId);
            sqlOperation.AddIntParameter("exercise_id", trainingLog.ExerciseId);
            sqlOperation.AddIntParameter("sets_completed", trainingLog.Sets);
            sqlOperation.AddIntParameter("repetition_completed", trainingLog.Reps);
            sqlOperation.AddDoubleParameter("weight_used", trainingLog.Weight);
            sqlOperation.AddTimeParameter("time_taken", trainingLog.Time);
            sqlOperation.AddDateTimeParameter("creation_date", trainingLog.CreationDate);

            sqlDao.ExecuteProcedure(sqlOperation);

        }

        private TrainingLog BuildtrainingLog(Dictionary<string, object> row)
        {
            var trainingLog = new TrainingLog()
            {

                Id = (int)row["progress_id"],
                UserId = (int)row["user_id"],
                Sets = (int)row["sets_completed"],
                Weight = Convert.ToDouble(row["weight_used"]),
                Time = (TimeSpan)row["time_taken"],
                RoutineDayId = (int)row["routine_day_id"],
                ExerciseId = (int)row["exercise_id"],
                CreationDate = (DateTime)row["creation_date"]
            };

            return trainingLog;
        }
    }
}

