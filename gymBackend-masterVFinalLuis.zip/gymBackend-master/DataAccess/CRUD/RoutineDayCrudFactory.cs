﻿using DataAccess.DAOs;
using DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.CRUD
{
    public class RoutineDayCrudFactory : CrudFactory
    {
        public RoutineDayCrudFactory() {
            sqlDao = SqlDao.GetInstance(); }

        public override void Create(BaseDTO baseDTO)
        {
            var routineDay = baseDTO as RoutineDay;
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "INS_ROUTINE_DAYS_PR"
            };
            sqlOperation.AddIntParameter("routine_id", routineDay.RoutineId);
            sqlOperation.AddIntParameter("day_number", routineDay.RoutineDayNumber);
            sqlOperation.AddDateTimeParameter("creation_date", routineDay.CreationDate);

            sqlDao.ExecuteProcedure(sqlOperation);
        }

        public override void DeleteByID(int id)
        {
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "DEL_ROUTINE_DAYS_BY_ID_PR"
            };
            sqlOperation.AddIntParameter("routine_day_id", id);

            sqlDao.ExecuteProcedure(sqlOperation);
        }

        public override List<T> RetrieveAll<T>()
        {
            var routineDayList = new List<T>();
            var sqlOperation = new SqlOperation
            {
                ProcedureName = "RET_ALL_ROUTINE_DAYS_PR"
            };
            var listResult = sqlDao.ExecuteQueryProcedure(sqlOperation);

            if (listResult.Count > 0)
            {
                foreach (var row in listResult)
                {
                    var routineDay = BuildRoutineDay(row);
                    routineDayList.Add((T)Convert.ChangeType(routineDay, typeof(T)));
                }
            }
            return routineDayList;
        }
        public T RetrieveById<T>(int id)
        {
            var sqlOperation = new SqlOperation();

            sqlOperation.AddIntParameter("routine_day_id", id);
            sqlOperation.ProcedureName = "RET_ROUTINEDAY_BY_ID_PR";
            var lstResults = sqlDao.ExecuteQueryProcedure(sqlOperation);

            if (lstResults.Count > 0)
            {
                var row = lstResults[0];

                var routineDay = (T)Convert.ChangeType(BuildRoutineDay(row), typeof(T));
                return routineDay;
            }
            return default(T);
        }
        public RoutineDay BuildRoutineDay(Dictionary<string, object> row)
        {
            var routineDay = new RoutineDay()
            {
                Id = (int)row["routine_day_id"],
                RoutineDayNumber = (int)row["day_number"],
                CreationDate = (DateTime)row["creation_date"],
                RoutineId = (int)row["routine_id"],
            };

            return routineDay;
        }


        public override void Update(BaseDTO baseDTO, int? id)
    {
        var routineDay = baseDTO as RoutineDay;
        var sqlOperation = new SqlOperation
        {
            ProcedureName = "UP_ROUTINE_DAYS_PR"
        };
        sqlOperation.AddIntParameter("routine_day_id", id.Value);
        sqlOperation.AddIntParameter("routine_id", routineDay.RoutineId);
        sqlOperation.AddIntParameter("day_number", routineDay.RoutineDayNumber);
        sqlOperation.AddDateTimeParameter("creation_date", routineDay.CreationDate);

            sqlDao.ExecuteProcedure(sqlOperation);
    }
}  }

