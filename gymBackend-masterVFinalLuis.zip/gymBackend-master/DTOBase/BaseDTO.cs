﻿namespace Card
{
    public class BaseDTO
    {

    }
}
