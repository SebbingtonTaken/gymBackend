﻿using CoreApp;
using DTOs;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainingLogController : ControllerBase
    {
        [HttpPost]
        [Route("CreateTrainingLog")]
        public ActionResult Create(TrainingLog trainingLog)
        {
            var tl = new TrainingLogManager();
            tl.Create(trainingLog);
            return Ok(trainingLog);
        }

        [HttpGet]
        [Route("RetrieveAll")]
        public ActionResult RetrieveAll()
        {
            var tl = new TrainingLogManager();
            var result = tl.RetrieveAll();
            return Ok(result);
        }

        [HttpGet]
        [Route("RetrieveById")]
        public ActionResult RetrieveById(int Id)
        {
            var tl = new TrainingLogManager();
            var result = tl.RetrieveById(Id);
            return Ok(result);
        }


        [HttpPut]
        [Route("Update")]
        public ActionResult Update(TrainingLog trainingLog)
        {
            var tl = new TrainingLogManager();
            tl.Update(trainingLog);
            return Ok(trainingLog);
        }
    }
}
