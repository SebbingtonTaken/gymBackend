﻿using CoreApp;
using DTOs;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
        [Route("api/[controller]")]
        [ApiController]

         public class RoutinesController : ControllerBase
    {
        
            [HttpPost]
            [Route("CreateRoutines")]
            public ActionResult Create(Routines routines)
            {
                var ro = new RoutineManager();
                ro.Create(routines);
                return Ok(routines);
            }

            [HttpGet]
            [Route("RetrieveAll")]
            public ActionResult RetrieveAll()
            {
                var ro = new RoutineManager();
                var result = ro.RetrieveAll();
                return Ok(result);
            }

            [HttpGet]
            [Route("RetrieveById")]
            public ActionResult RetrieveById(int Id)
            {
                var ro = new RoutineManager();
                var result = ro.RetrieveById(Id);
                return Ok(result);
            }

            [HttpGet]
          [Route("RetrieveRoutineDaysByRoutineId")]
          public ActionResult RetrieveRoutineDaysByRoutineId(int routineId)
          {
            var ro = new RoutineManager();
            var result = ro.RetrieveRoutineDaysByRoutineId(routineId);
            return Ok(result);
           }

          [HttpGet]
          [Route("RetrieveRoutinesByUserId")]
          public ActionResult RetrieveRoutinesByUserId(int userId)
           {
            var ro = new RoutineManager();
            var result = ro.RetrieveRoutinesByUserId(userId);
            return Ok(result);
          }
        [HttpPut]
            [Route("Update")]
            public ActionResult Update(Routines routines)
            {
                var ro = new RoutineManager();
                ro.Update(routines);
                return Ok(routines);
            }
        }
    }



