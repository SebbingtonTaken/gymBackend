﻿using CoreApp;
using DTOs;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    
        [Route("api/[controller]")]
        [ApiController]

       public class RoutineDayController : ControllerBase
        {
        

            [HttpPost]
            [Route("CreateRoutineDay")]
            public ActionResult Create(RoutineDay routineDay)
            {
                var rd = new RoutineDayManager();
                rd.Create(routineDay);
                return Ok(routineDay);
            }

            [HttpGet]
            [Route("RetrieveAll")]
            public ActionResult RetrieveAll()
            {
                var rd = new RoutineDayManager();
                var result = rd.RetrieveAll();
                return Ok(result);
            }

            [HttpGet]
            [Route("RetrieveById")]
            public ActionResult RetrieveById(int Id)
            {
                var rd = new RoutineDayManager();
                var result = rd.RetrieveById(Id);
                return Ok(result);
            }


            [HttpPut]
            [Route("Update")]
            public ActionResult Update(RoutineDay routineDay)
            {
                var rd = new RoutineDayManager();
                rd.Update(routineDay);
                return Ok(routineDay);
            }
        }
    }

