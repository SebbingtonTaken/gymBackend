﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOs
{
    public class RoutineDay: BaseDTO
    {
        public int RoutineId {get; set; }
        public int RoutineDayNumber { get; set; }
     

    }
}
