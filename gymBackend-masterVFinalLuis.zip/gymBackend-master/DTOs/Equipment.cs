﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOs
{
    public class Equipment: BaseDTO
    {
        public string EquipmentName { get; set; }
        public int LocationNumber { get; set; }
}
    
}
