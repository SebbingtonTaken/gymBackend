﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOs
{
    public class Routines : BaseDTO
    {
        public String RoutineType { get; set; }
        public int UserId  { get; set; }
        public int EmployeeId { get; set; }
        public List<RoutineDay> RoutineDay { get; set; }
    }
}
