﻿namespace DTOs
{
    public class BaseDTO
    {
        public int Id { get; set; }
        public DateTime CreationDate { get; set; }  
    }
}
